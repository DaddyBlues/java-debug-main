lgtm,codescanning
* The data-flow library has been improved to represent reads and writes of promoted fields correctly, which may lead to more alerts.
