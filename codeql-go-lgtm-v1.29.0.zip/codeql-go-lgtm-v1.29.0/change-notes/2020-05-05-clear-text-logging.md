lgtm,codescanning
* The query "Clear-text logging of sensitive information" has been improved to recognize more logging APIs, which may lead to more alerts.