lgtm,codescanning
* A bug has been fixed that could cause the analysis not to terminate in the presence of cycles through embedded struct fields.