lgtm,codescanning
* Support for the [k8s.io/apimachinery/pkg/runtime](https://godoc.org/k8s.io/apimachinery/pkg/runtime) library has been added, which may lead to more results from the security queries.
