lgtm,codescanning
* The query "Clear-text logging of sensitive information" has been improved to recognize more sources of sensitive data, which may lead to more alerts. The query is now also more precise, which may reduce the number of false positives.
