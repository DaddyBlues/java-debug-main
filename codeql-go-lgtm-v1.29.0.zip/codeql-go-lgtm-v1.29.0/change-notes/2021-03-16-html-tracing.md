lgtm,codescanning
* Support for extracting HTML files has been added, alongside support for Raw Revel templates.
