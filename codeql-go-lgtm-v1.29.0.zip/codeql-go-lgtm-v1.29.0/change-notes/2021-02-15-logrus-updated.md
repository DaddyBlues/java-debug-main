lgtm,codescanning
* Modeling of the `Logrus` logging library has been improved.  This may cause the `go/clear-text-logging` query to return more results when sensitive data is exposed using this library.
