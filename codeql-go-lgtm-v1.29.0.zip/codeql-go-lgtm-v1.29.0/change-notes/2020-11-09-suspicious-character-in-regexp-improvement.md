lgtm,codescanning
* The query "Suspicious characters in a regular expression" has been improved to recognize raw string literals, which should lead to fewer false positives.
