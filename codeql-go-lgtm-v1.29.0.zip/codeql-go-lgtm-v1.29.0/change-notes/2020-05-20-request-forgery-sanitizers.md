lgtm,codescanning
* The query "Uncontrolled data used in network request" is now more precise, which may reduce the number of false positives.
