lgtm,codescanning
* The accuracy of the `go/allocation-size-overflow` query was improved, excluding more false-positives in which a small array could be mistaken for one of unbounded size.
