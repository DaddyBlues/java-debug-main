lgtm,codescanning
* Modeling of the `archive/tar` and `archive/zip` packages has been added, which may lead to more
  results from the security queries.
