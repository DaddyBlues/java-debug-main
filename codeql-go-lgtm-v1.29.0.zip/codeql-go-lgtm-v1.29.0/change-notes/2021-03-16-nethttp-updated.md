lgtm,codescanning
* Added support for the `Transport.RoundTrip` method in `net/http`.
