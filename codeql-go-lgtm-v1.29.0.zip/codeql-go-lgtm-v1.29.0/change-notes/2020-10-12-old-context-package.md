lgtm,codescanning
* Added support for the `golang.org/x/net/context` package, which was already supported under its modern standard-library name `context`.
