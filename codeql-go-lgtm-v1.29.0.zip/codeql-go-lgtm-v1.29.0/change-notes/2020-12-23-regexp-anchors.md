lgtm,codescanning
* Query `go/regex/missing-regexp-anchor` now recognizes the start- and end-of-text anchors `\A` and `\z`. This reduces false-positives relating to unanchored expressions.
