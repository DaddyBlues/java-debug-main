lgtm,codescanning
* A new query `go/stack-trace-exposure` has been added. The query flags exposure of a stack trace to a remote party.
