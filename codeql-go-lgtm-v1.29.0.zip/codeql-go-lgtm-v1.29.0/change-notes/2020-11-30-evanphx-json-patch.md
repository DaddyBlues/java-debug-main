lgtm,codescanning
* Support for the [json-patch](https://github.com/evanphx/json-patch/) library has been added, which may lead to more results from the security queries.
