lgtm,codescanning
* Models for gokit request sources have been added as an opt-in feature; import `semmle.go.frameworks.GoKit` in a query to enable these sources.
