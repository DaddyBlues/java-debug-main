lgtm,codescanning
* The data-flow library has been improved, which affects and improves most security queries. In particular,
  flow through functions involving nested field reads and writes is now modeled more fully.
