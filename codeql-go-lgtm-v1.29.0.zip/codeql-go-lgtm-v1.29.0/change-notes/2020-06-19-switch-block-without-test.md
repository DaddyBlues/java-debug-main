lgtm,codescanning
* A bug has been fixed that could cause the incorrect analysis of control flow around switch statements.
