lgtm,codescanning
* A function which compares a value with a list of constants now acts as a sanitizer guard. This should lead to fewer false positive results.
