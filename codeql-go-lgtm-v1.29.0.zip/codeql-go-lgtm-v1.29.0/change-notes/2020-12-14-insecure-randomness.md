lgtm,codescanning
* Query "Use of insufficient randomness as the key of a cryptographic algorithm" (`go/insecure-randomness`) is promoted from experimental status. This checks for use of an insecure random number generator in a security component.
