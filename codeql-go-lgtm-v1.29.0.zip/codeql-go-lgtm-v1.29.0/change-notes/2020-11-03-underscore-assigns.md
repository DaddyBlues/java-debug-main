lgtm,codescanning
* Fixed a bug that meant partially-ignored parallel assignments, such as `x, _ := a, b`, could produce an incorrect control-flow graph.
