package net.sourceforge.pmd.cpd;

/*
 * This is a stub definition for pmd's SourceCode class
 * including only the API used by the GoLanguage class.
 */

public class SourceCode {
  public String getFileName() {
    return null;
  }
}
