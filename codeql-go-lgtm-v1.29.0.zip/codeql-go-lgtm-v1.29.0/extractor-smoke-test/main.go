package main

import "fmt"

func main() {
	var i int = 1
	fmt.Println(i)
}
