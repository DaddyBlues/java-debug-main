package main

// This file tests that the extractor does not crash on files that do not
// end in a newline, so it is important not to autoformat this file.

// autoformat-ignore

func main() {
}