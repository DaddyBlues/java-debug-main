package main

func main() {
	fmt.Println("a")
	fmt.Println(a)
}
