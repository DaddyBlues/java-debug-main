package test

type Test struct {
	Field string `json:{ field: {} }"`
}
