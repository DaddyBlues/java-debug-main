package main

import "regexp"

func test(r *regexp.Regexp) {}

func swap(x int, y int) (int, int) {
	return y, x
}

func main() {}
