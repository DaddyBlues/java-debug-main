package main

const fmt = "formatted %s string"
const text = "test"

func main() {

}
