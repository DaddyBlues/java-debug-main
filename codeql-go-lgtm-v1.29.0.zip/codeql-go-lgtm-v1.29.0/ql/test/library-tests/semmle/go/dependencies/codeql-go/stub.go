package codeqlgo
