Revel example adapted from [revel-examples](https://github.com/revel/revel-examples).

See `LICENSE` for license information.
