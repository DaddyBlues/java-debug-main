package main

import "fmt"

const message = "Hello, world!"

func sayHello() {
	fmt.Println(message)
}
