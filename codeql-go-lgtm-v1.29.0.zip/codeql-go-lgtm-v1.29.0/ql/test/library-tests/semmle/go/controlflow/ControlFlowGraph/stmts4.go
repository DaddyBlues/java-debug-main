package main

var _ int

func test18(x int) float32
