package main

func test19() int {
	if true {
		return 42
	}
	return 23
}
