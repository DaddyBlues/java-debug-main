//go:build !linux
// +build !linux

package main

const linux = false
