package main

import "github.com/github/nonexistent"

func main() {
	nonexistent.A()
}
