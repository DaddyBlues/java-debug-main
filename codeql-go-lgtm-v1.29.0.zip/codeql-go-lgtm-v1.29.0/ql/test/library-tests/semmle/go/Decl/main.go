package main

type status int

type intlist = []int
