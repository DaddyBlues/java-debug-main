package main

type User struct {
	Id   int64
	Name string
}

func main() {
}
