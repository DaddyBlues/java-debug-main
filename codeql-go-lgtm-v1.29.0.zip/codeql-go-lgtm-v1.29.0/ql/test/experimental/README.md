This directory contains tests for [experimental](../../docs/experimental.md) CodeQL queries and libraries.
