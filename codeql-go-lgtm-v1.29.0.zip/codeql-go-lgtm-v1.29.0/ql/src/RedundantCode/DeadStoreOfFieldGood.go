package main

func (c *counter) resetGood() {
	c.val = 0
}
