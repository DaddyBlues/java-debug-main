package main

func avg(x, y float64) float64 {
	return (x + x) / 2
}
