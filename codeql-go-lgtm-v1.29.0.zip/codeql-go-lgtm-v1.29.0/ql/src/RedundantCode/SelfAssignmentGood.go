package main

func (r *Rect) setHeightGood(height int) {
	r.height = height
}
