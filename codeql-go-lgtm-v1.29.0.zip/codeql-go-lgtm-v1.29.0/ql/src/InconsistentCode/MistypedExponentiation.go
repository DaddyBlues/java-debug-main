package main

import "fmt"

func main() {
	fmt.Println(2 ^ 32) // should be 1 << 32
}
